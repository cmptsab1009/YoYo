﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using YoYoTest.Core.Interfaces;
using YoYoTest.Core.ResponseModel;

namespace YoYoTest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AthleteController : ControllerBase
    {
        private readonly ILogger<AthleteController> _logger;
        private  IConfiguration _configuration { get; }

       // private readonly IAthlete _athlete;
        public AthleteController(ILogger<AthleteController> logger, IConfiguration configuration)//, IAthlete athlete
        {
            _logger = logger;
            _configuration = configuration;
            //_athlete = athlete;
        }

        [HttpGet]
        public List<AthletesResponse> Get()
        {
            // this will be called when we will have DB methods
            //return _athlete.GetAllAthlete().Result;

            // Temp method to get list of athletes from appsetting files
            var AthletesArray = _configuration
                            .GetSection("Atheltes")
                            .GetChildren()
                            .Select(x => x.Value)
                            .ToArray();
            var athletes = new List<AthletesResponse>();
            foreach (var athlet in AthletesArray)
            {
                athletes.Add(new AthletesResponse { UserId=Guid.NewGuid(), Name = athlet });
            }
            return athletes;
            
        }
    }
}
