﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using YoYoTest.Core.Constants;
using YoYoTest.Core.Exceptions;
using YoYoTest.Core.Interfaces;
using YoYoTest.Core.RequestModel;
using YoYoTest.Core.ResponseModel;
using YoYoTest.Data.Models;
using YoYoTest.Provider.Mapper;
using YoYoTest.Repository.UnitOfWork;

namespace YoYoTest.Provider.Services
{
    public class UserService : IUserService
    {
        private readonly IUnitOfWork _unitOfWork;
        public IConfiguration _configuration { get; }
        private readonly ILogger _logger;

        public UserService(IConfiguration configuration, IUnitOfWork unitOfWork, ILogger<UserService> logger)
        {
            _configuration = configuration;
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public async Task<LoginResponse> Login(LoginRequest model)
        {
            if (model == null)
                throw new BadRequestException(Constant.BadRequest);

            var user = _unitOfWork.GetRepository<User>().GetAll()?
                 .Where(x => x.Email == model.Email && x.Password == model.Password).FirstOrDefaultAsync();

            // return null if user not found
            if (user.Result == null)
                throw new NotFoundException(Constant.InvalidLogin);

            // authentication successful so generate token
            var token = generateToken(user.Result);
            return new LoginResponse(user.Result, token);
        }

        public async Task<List<RegisterResponse>> GetAll()
        {
            var list = await (_unitOfWork.GetRepository<User>()?.GetAll()?.ToListAsync()).ConfigureAwait(false);
            if (list == null || list?.Count == 0)
                throw new NotFoundException(Constant.RecordsNotFound);
            return list.Select(x => AutoMap.Mapping<User, RegisterResponse>(x)).ToList();
        }

        public async Task<List<RegisterResponse>> AddUser(RegisterRequest registerRequest)
        {
            if (registerRequest == null)
                throw new BadRequestException(Constant.BadRequest);

            try
            {
                if (await (_unitOfWork.GetRepository<User>()?.GetAll().AnyAsync(x => x.Email == registerRequest.Email)).ConfigureAwait(false))
                    throw new AlreadyExistsException(Constant.EmailAlreadyExist);
                var user = AutoMap.Mapping<RegisterRequest, User>(registerRequest);
                _unitOfWork.GetRepository<User>().Add(user);
                await (_unitOfWork?.SaveChangesAsync()).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw (ex);
            }
            return await GetAll().ConfigureAwait(false);
        }
        private string generateToken(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["AppSettings:Secret"]);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim("id", user.Id.ToString()) }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
