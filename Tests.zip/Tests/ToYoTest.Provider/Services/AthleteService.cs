﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YoYoTest.Core.Constants;
using YoYoTest.Core.Exceptions;
using YoYoTest.Core.Interfaces;
using YoYoTest.Core.RequestModel;
using YoYoTest.Core.ResponseModel;
using YoYoTest.Data.Models;
using YoYoTest.Provider.Mapper;
using YoYoTest.Repository.UnitOfWork;

namespace YoYoTest.Provider.Services
{
    public class AthleteService : IAthlete
    {
        private readonly IUnitOfWork _unitOfWork;
        public IConfiguration _configuration { get; }
        private readonly ILogger _logger;

        public AthleteService(IConfiguration configuration, IUnitOfWork unitOfWork, ILogger<UserService> logger)
        {
            _configuration = configuration;
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public async Task<List<AthletesResponse>> GetAllAthlete()
        {
            var list = await(_unitOfWork.GetRepository<athlete>()?.GetAll()?.ToListAsync()).ConfigureAwait(false);
            if (list == null || list?.Count == 0)
                throw new NotFoundException(Constant.RecordsNotFound);

            return list.Select(x => AutoMap.Mapping<athlete, AthletesResponse>(x)).ToList();
        }
    }
}
