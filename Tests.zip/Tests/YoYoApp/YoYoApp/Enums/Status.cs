﻿namespace YoYoApp.Enums
{
    public enum Status
    {
        Runnig = 0,
        Warned = 1,
        Stoped = 2,
    }
}
