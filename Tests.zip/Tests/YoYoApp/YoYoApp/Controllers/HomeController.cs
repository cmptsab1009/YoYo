﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using YoYoApp.Models;

namespace YoYoApp.Controllers
{
    public class HomeController : Controller
    {
        private static string[] Athletes = { "Lokesh", "Deepak", "Narendra" };
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            var athletes = new List<Athlete>();
            foreach (var athlet in Athletes)
            {
                athletes.Add(new Athlete { Name = athlet });
            }
            return View(athletes);
        }

        public IActionResult StartTest()
        {
            var jsonString =System.IO.File.ReadAllText("Files/fitnessrating_beeptest.json");
            var fitnessRatingBeepList = JsonSerializer.Deserialize<List<FitnessRatingBeepTest>>(jsonString);
            return new JsonResult(fitnessRatingBeepList);
        }

        public IActionResult WarnAthletes(int athleteId)
        {
            return new JsonResult("ok");
        }

        public IActionResult StopAthletes(int athleteId)
        {
            return new JsonResult("ok");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
