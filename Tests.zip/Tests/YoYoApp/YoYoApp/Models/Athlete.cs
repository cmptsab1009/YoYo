﻿namespace YoYoApp.Models
{
    using YoYoApp.Enums;

    public class Athlete
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Status Status { get; set; }
    }
}
