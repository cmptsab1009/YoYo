﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;
using YoYoTest.Core.Helper;
using YoYoTest.Data.Context;
using YoYoTest.Repository.Repository;

namespace YoYoTest.Repository.UnitOfWork
{
    /// <summary>
    /// Unit of work
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ILogger _logger;
        /// <summary>
        /// Declare DbContect 
        /// </summary>
        private readonly AppDbContext _appDbContext;
        /// <summary>
        /// Declare Dictionary of the class
        /// </summary>
        private Dictionary<Type, object> _repositories;
        /// <summary>
        /// Declare bool variables
        /// </summary>
        private bool disposed = false;
        public UnitOfWork(AppDbContext applicationDbContext, ILogger<UnitOfWork> logger)
        {
            _appDbContext = applicationDbContext;
            _logger = logger;
        }
        /// <summary>
        /// Get the repository of entity
        /// </summary>
        /// <typeparam name="TEntity">Entity</typeparam>
        /// <returns>Entity Repository</returns>
        public IRepositories<TEntity> GetRepository<TEntity>()
        where TEntity : class
        {
            if (_repositories == null)
            {
                _repositories = new Dictionary<Type, object>();
            }
            var type = typeof(TEntity);
            if (!_repositories.ContainsKey(type))
            {
                _repositories[type] = new Repositories<TEntity>(_appDbContext);
            }
            return (IRepositories<TEntity>)_repositories[type];
        }
        /// <summary>
        /// save the entity DbContext details
        /// </summary>
        /// <returns>Successfully save the records return true else false.</returns>
        public bool SaveChanges()
        {
            using (var dbContextTransaction = _appDbContext.Database.BeginTransaction())
            {
                try
                {
                    _appDbContext.SaveChanges();
                    dbContextTransaction.Commit();
                    return true;
                }
                catch (DbUpdateException ex)
                {
                    dbContextTransaction.Rollback();
                    _logger.LogError(CommonHelper.GetExceptionMessage("Exception thrown while DbContext save changes from", ex));
                    return false;
                }
            }
        }
        /// <summary>
        /// save the entity DbContext details by async method
        /// </summary>
        /// <returns>Successfully save the records return true else false.</returns>
        public async Task<bool> SaveChangesAsync()
        {
            using (var dbContextTransaction = _appDbContext.Database.BeginTransaction())
            {
                try
                {
                    await _appDbContext.SaveChangesAsync().ConfigureAwait(false);
                    dbContextTransaction.Commit();
                    return true;
                }
                catch (DbUpdateException ex)
                {
                    dbContextTransaction.Rollback();
                    _logger.LogError(CommonHelper.GetExceptionMessage("Exception thrown while DbContext save changes from", ex));
                    return false;
                }
            }
        }

        #region IDisposable Support        
        /// <summary>
        /// Public implementation of Dispose pattern callable by consumers.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        /// <summary>
        /// Protected implementation of Dispose pattern.
        /// </summary>
        /// <param name="disposing">bool parameters</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
            {
                return;
            }

            if (disposing && _appDbContext != null)
            {
                _appDbContext.Dispose();
            }
            disposed = true;
        }
        #endregion
    }
}
