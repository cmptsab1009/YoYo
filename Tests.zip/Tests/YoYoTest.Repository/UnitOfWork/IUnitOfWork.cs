﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using YoYoTest.Repository.Repository;

namespace YoYoTest.Repository.UnitOfWork
{
    /// <summary>
    /// Interface for unit of work 
    /// </summary>
    public interface IUnitOfWork : IDisposable
    {
        /// <summary>
        /// Get the repository of entity
        /// </summary>
        IRepositories<TEntity> GetRepository<TEntity>()
          where TEntity : class;
        /// <summary>
        /// Save the entity
        /// </summary>
        bool SaveChanges();
        /// <summary>
        /// Asynchronous save the entity
        /// </summary>
        Task<bool> SaveChangesAsync();
    }
}
