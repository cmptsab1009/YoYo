﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace YoYoTest.Repository.Repository
{
    /// <summary>
    /// Common repository for Entity
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    public interface IRepositories<TEntity> where TEntity : class
    {
        /// <summary>
        /// Find the entity details 
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>        
        IQueryable<TEntity> FindBy(Expression<Func<TEntity, bool>> predicate);
        /// <summary>
        /// Get all entity details
        /// </summary>
        /// <returns></returns>
        IQueryable<TEntity> GetAll();
        /// <summary>
        /// Get all entity details by include
        /// </summary>
        /// <param name="include"></param>
        /// <returns></returns>
        IQueryable<TEntity> GetAll(string include);
        /// <summary>
        /// Add entity details
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        EntityState Add(TEntity entity);
        /// <summary>
        /// Delete entity details
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        EntityState Delete(TEntity entity);
        /// <summary>
        /// Update entity details 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        EntityState Update(TEntity entity);
    }
}
