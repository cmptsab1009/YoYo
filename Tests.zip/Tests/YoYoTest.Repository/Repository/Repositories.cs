﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace YoYoTest.Repository.Repository
{
    /// <summary>
    /// Common repository for Entity
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    [ExcludeFromCodeCoverage]
    public class Repositories<TEntity> : IRepositories<TEntity> where TEntity : class
    {
        /// <summary>
        /// Declare entity
        /// </summary>
        private readonly DbSet<TEntity> _entities;

        public Repositories(DbContext dbContext)
        {
            _entities = dbContext?.Set<TEntity>();
        }
        /// <summary>
        /// Add the entity details
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public EntityState Add(TEntity entity)
        {
            return _entities.Add(entity).State;
        }
        /// <summary>
        /// Find the entity details 
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public IQueryable<TEntity> FindBy(Expression<Func<TEntity, bool>> predicate)
        {
            return _entities.Where(predicate);
        }
        /// <summary>
        /// Get all entity details
        /// </summary>
        /// <returns></returns>
        public IQueryable<TEntity> GetAll()
        {
            return _entities;
        }
        /// <summary>
        /// Get all entity details by include
        /// </summary>
        /// <param name="include"></param>
        /// <returns></returns>
        public IQueryable<TEntity> GetAll(string include)
        {
            return _entities.Include(include);
        }
        /// <summary>
        /// Delete entity details
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public EntityState Delete(TEntity entity)
        {
            return _entities.Remove(entity).State;
        }
        /// <summary>
        /// Update entity details 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public virtual EntityState Update(TEntity entity)
        {
            return _entities.Update(entity).State;
        }
    }
}
