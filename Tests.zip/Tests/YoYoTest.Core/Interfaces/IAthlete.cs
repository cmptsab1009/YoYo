﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using YoYoTest.Core.RequestModel;
using YoYoTest.Core.ResponseModel;

namespace YoYoTest.Core.Interfaces
{
    public interface IAthlete
    {
        Task<List<AthletesResponse>> GetAllAthlete();
    }
}

