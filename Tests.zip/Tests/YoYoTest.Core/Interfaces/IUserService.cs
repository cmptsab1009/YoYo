﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using YoYoTest.Core.RequestModel;
using YoYoTest.Core.ResponseModel;

namespace YoYoTest.Core.Interfaces
{
    public interface IUserService
    {
        Task<LoginResponse> Login(LoginRequest model);
        Task<List<RegisterResponse>> GetAll();
        Task<List<RegisterResponse>> AddUser(RegisterRequest registerRequest);
    }
}
