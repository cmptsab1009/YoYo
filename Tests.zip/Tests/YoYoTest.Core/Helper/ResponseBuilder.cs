﻿using System;
using System.Collections.Generic;
using System.Text;
using YoYoTest.Core.ViewModels;

namespace YoYoTest.Core.Helper
{
    public static class ResponseBuilder
    {
        public static HttpResponseErrorModel HandleResponse(int status, string detail, string stackTrace = null)
        {
            return new HttpResponseErrorModel()
            {
                Id = "",
                Code = "",
                Status = status,
                Title = "",
                Detail = detail,
                Path = "",
                StackTrace = stackTrace
            };
        }
    }
}
