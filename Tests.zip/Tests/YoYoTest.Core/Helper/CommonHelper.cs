﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace YoYoTest.Core.Helper
{
    public static class CommonHelper
    {
        /// <summary>
        /// Return the file size in MB from base64 string
        /// </summary>
        /// <param name="base64String">Base64 encoded file</param>
        /// <returns>size of file in MB(double)</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Wrong base64string handling")]
        public static double GetFileSizeInMbFromBase64(string base64String)
        {
            var result = 0;
            try
            {
                byte[] fileBytes = Convert.FromBase64String(GetBase64String(base64String));
                var fileSize = (fileBytes?.Length / 1024) / 1024;
                if (fileSize.HasValue)
                {
                    result = fileSize.Value;
                }
            }
            catch
            {
                result = 0;
            }
            return result;
        }

        /// <summary>
        /// Returns the list of Guid's from the given comma separated string
        /// </summary>
        /// <param name="value">Comma separated string value</param>
        /// <param name="delimiter">Delimiter to split the string</param>
        /// <returns>List of Guid</returns>
        public static List<Guid> DelimitedStringToListOfGuids(string value, char delimiter)
        {
            List<Guid> guids = new List<Guid>();
            Guid guid;
            value?.Split(delimiter).ToList().ForEach(
                delegate (string s)
                {
                    guid = Guid.NewGuid();
                    if (Guid.TryParse(s, out guid))
                        guids.Add(guid);
                });
            return guids;
        }

        /// <summary>
        /// Getting throw exceptions Message and StackTrace
        /// </summary>
        /// <param name="gettingFrom">From message</param>
        /// <param name="ex">Exception</param>
        public static string GetExceptionMessage(string gettingFrom, Exception ex)
        {
            return ex == null ? string.Empty : ($"{gettingFrom}, Message : {Regex.Replace(ex.Message, Environment.NewLine, " ")}, StackTrace : {Regex.Replace(ex.StackTrace, Environment.NewLine, " ")}");
        }

        /// <summary>
        /// Handled exceptions for the input is not a valid Base-64 string
        /// </summary>
        /// <param name="tierImage">Image base64 string</param>
        public static string GetBase64String(string tierImage)
        {
            if (!string.IsNullOrEmpty(tierImage))
            {
                string[] split = tierImage.Split(',');
                if (split.Length > 1)
                    tierImage = split[1];
            }
            return tierImage;
        }

        public static Uri GetUri(HttpRequest request, bool addPath = true, bool addQuery = true)
        {
            var uriBuilder = new UriBuilder
            {
                Scheme = request?.Scheme,
                Host = request?.Host.Host,
                Port = request?.Host.Port ?? 80,
                Path = addPath ? request?.Path.ToString() : default(string),
                Query = addQuery ? request?.QueryString.ToString() : default(string)
            };
            return uriBuilder.Uri;
        }
    }
}
