﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYoTest.Core.ResponseModel
{
    public class WarnAtheteResponse
    {
        public bool Status { get; set; }
    }
}
