﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYoTest.Core.ResponseModel
{
    public class RegisterResponse
    {
        public Guid UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
