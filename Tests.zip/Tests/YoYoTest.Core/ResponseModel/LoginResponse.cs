﻿using System;
using System.Collections.Generic;
using System.Text;
using YoYoTest.Data.Models;

namespace YoYoTest.Core.ResponseModel
{
    public class LoginResponse
    {
        public Guid UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Token { get; set; }
        public LoginResponse(User user, string token)
        {
            UserId = user.UserId;
            Name = user.Name;
            Email = user.Email;
            Token = token;
        }
    }
}
