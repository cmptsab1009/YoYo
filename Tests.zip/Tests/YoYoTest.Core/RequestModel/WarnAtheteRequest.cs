﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYoTest.Core.RequestModel
{
    public class WarnAtheteRequest
    {
        public Guid UserId { get; set; }
    }
}
