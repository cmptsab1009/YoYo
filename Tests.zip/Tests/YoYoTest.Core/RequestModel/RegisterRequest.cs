﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using YoYoTest.Core.Constants;

namespace YoYoTest.Core.RequestModel
{
    public class RegisterRequest
    {
        [Required]
        [StringLength(50, MinimumLength = 1, ErrorMessageResourceName = Constant.validlength)]
        public string Name { get; set; }
        [Required]
        [StringLength(30, MinimumLength = 1, ErrorMessageResourceName = Constant.validlength)]
        [DataType(DataType.EmailAddress, ErrorMessageResourceName = Constant.validemail)]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [StringLength(30, MinimumLength = 1, ErrorMessageResourceName = Constant.validlength)]
        public string Password { get; set; }
    }
}
