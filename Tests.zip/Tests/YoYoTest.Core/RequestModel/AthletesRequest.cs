﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYoTest.Core.RequestModel
{
    public class AthletesRequest
    {
    }
}
