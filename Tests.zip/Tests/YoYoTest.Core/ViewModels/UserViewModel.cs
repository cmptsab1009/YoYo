﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYoTest.Core.ViewModels
{
    class UserViewModel
    {
    }
}
