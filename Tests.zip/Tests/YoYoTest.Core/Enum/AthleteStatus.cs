﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYoTest.Core.Enum
{
   public enum AthleteStatus
    {
        Runnig = 0,
        Warned = 1,
        Stoped = 2
    }
}
